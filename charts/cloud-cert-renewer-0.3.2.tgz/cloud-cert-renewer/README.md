# cloud-cert-renewer

A Helm chart for cloud certificate renewal service supporting CDN and Load Balancer. Supports multiple cloud providers (currently Alibaba Cloud, with architecture designed for multi-cloud extension).

## Prerequisites

**Required:**

- Kubernetes 1.19+
- Helm 3.0+

**Recommended:**

- cert-manager (for automatic certificate management)
- Reloader (for automatic deployment on certificate updates)

## Installation

### Basic Installation

```bash
helm install cloud-cert-renewer ./helm/cloud-cert-renewer
```

### Installation with Custom Values

```bash
# Using --set with comma-separated string (simpler for command line)
helm install cloud-cert-renewer ./helm/cloud-cert-renewer \
  --set serviceType=cdn \
  --set cdn.domainName="example.com,www.example.com" \
  --set image.tag=v0.1.0

# Or using --set with YAML list format (more verbose)
helm install cloud-cert-renewer ./helm/cloud-cert-renewer \
  --set serviceType=cdn \
  --set cdn.domainName[0]=example.com \
  --set cdn.domainName[1]=www.example.com \
  --set image.tag=v0.1.0
```

```bash

# Load Balancer with independent ports per instance
helm install cloud-cert-renewer ./helm/cloud-cert-renewer \
  --set serviceType=lb \
  --set 'lb.listeners[0].instanceId=lb-aaa' \
  --set 'lb.listeners[0].listenerPort=443' \
  --set 'lb.listeners[1].instanceId=lb-bbb' \
  --set 'lb.listeners[1].listenerPort=8443' \
  --set image.tag=v0.1.0

```

**Note:** For `cdn.domainName`, you can use either:

- **YAML list format** (recommended in values files): `domainName: ["example.com", "www.example.com"]`
- **Comma-separated string** (backward compatible): `domainName: "example.com,www.example.com"`

The list format is more readable and less error-prone, especially for long domain lists.

### Installation from Values File

```bash
helm install cloud-cert-renewer ./helm/cloud-cert-renewer \
  -f my-values.yaml
```

## Configuration

The following table lists the configurable parameters and their default values:

| Parameter                              | Description                           | Default                      |
| -------------------------------------- | ------------------------------------- | ---------------------------- |
| `serviceType`                          | Service type: `cdn` or `lb` (backward compatible: `slb`) | `cdn`                        |
| `cloudProvider`                         | Cloud provider: `alibaba`, `aws`, `azure`, etc. (currently supports Alibaba Cloud) | `alibaba`                    |
| `authMethod`                           | Authentication method: `access_key`, `sts`, `iam_role`, `oidc`, `service_account`, `env` | `access_key`                 |
| `image.repository`                     | Image repository                      | `cloud-cert-renewer`         |
| `image.tag`                            | Image tag                             | `latest`                     |
| `image.pullPolicy`                     | Image pull policy                     | `IfNotPresent`               |
| `imagePullSecrets`                     | List of image pull secret names for private registries | `[]`                         |
| `replicas`                             | Number of replicas                    | `1`                          |
| `cdn.domainName`                       | CDN domain names (YAML list preferred, or comma-separated string) | `["schema.amugua.com"]`      |
| `cdn.region`                           | CDN region                            | `cn-hangzhou`                |
| `lb.instanceId`                        | Load Balancer instance IDs (YAML list preferred, or comma-separated string) | `""`                         |
| `lb.listeners`                         | Structured instanceId/port pairs (takes precedence over instanceId + listenerPort) | `[]`                         |
| `lb.listenerPort`                      | Load Balancer listener port (shared, used when listeners is not set) | `443`                        |
| `lb.region`                            | Load Balancer region                  | `cn-hangzhou`                |
| `lb.certSource`                        | Certificate upload path: `slb` (SLB self-managed store) or `cas` (via CAS, for WAF). Prefer this over `slb.certSource`. Unset in chart defaults so `slb.certSource` can fall through; template default is `slb`. | `slb` (template) |
| `slb.instanceId`                       | SLB instance ID (old name, backward compatible)    | `""`                         |
| `slb.region`                           | SLB region (old name, backward compatible)         | `cn-hangzhou`                |
| `slb.certSource`                       | Deprecated alias for `lb.certSource`; used only when `lb.certSource` is unset | unset |
| `secrets.cloudCredentials.name`        | Cloud service credentials secret name (new name, preferred) | `cloud-credentials`           |
| `secrets.cloudCredentials.accessKeyIdKey` | Access key ID key name in credentials secret | `access-key-id`              |
| `secrets.cloudCredentials.accessKeySecretKey` | Access key secret key name in credentials secret | `access-key-secret`          |
| `secrets.cloudCredentials.securityTokenKey` | Security token key in credentials secret (optional, for STS) | `""`                         |
| `secrets.alibabaCloudCredentials.name` | Alibaba Cloud credentials secret name (old name, backward compatible) | `alibaba-cloud-credentials`  |
| `secrets.alibabaCloudCredentials.accessKeyIdKey` | Access key ID key name (old name, backward compatible) | `access-key-id`              |
| `secrets.alibabaCloudCredentials.accessKeySecretKey` | Access key secret key name (old name, backward compatible) | `access-key-secret`          |
| `secrets.certificate.name`             | Certificate secret name               | `cert-secret`                |
| `secrets.certificate.certKey`          | Certificate key name in secret         | `tls.crt`                    |
| `secrets.certificate.privateKeyKey`   | Private key key name in secret         | `tls.key`                    |
| `forceUpdate`                          | Force update certificate even if same | `false`                      |
| `webhook.enabled`                       | Enable webhook notifications          | `false`                      |
| `webhook.url`                           | Webhook endpoint URL                  | `""`                         |
| `webhook.timeout`                       | Webhook request timeout in seconds    | `30`                         |
| `webhook.retryAttempts`                 | Number of retry attempts on failure   | `3`                          |
| `webhook.retryDelay`                    | Initial delay between retries in seconds | `1.0`                    |
| `webhook.enabledEvents`                 | Comma-separated events to notify on   | `""` (all events)           |
| `webhook.secret.name`                   | Secret containing webhook URL         | `""`                         |
| `webhook.secret.key`                    | Key in secret for webhook URL         | `webhook-url`               |
| `reloader.enabled`                     | Enable Reloader annotations           | `true`                       |
| `reloader.auto`                        | Enable automatic reload (Reloader)     | `true`                       |
| `reloader.search`                      | Enable search mode (Reloader)          | `true`                       |
| `initContainer.resources`              | Init container resource requests/limits | See [Resources](#resources)  |
| `mainContainer.image`                  | Main container image (placeholder)     | `busybox:latest`             |
| `mainContainer.resources`              | Main container resource requests/limits | See [Resources](#resources) |
| `labels`                               | Additional labels for Deployment       | `{}`                         |
| `annotations`                          | Additional annotations for Deployment  | `{}`                         |
| `podAnnotations`                       | Additional annotations for Pods       | `{}`                         |
| `nodeSelector`                         | Node selector for pod scheduling        | `{}`                         |
| `tolerations`                          | Tolerations for pod scheduling          | `[]`                         |
| `affinity`                             | Affinity rules for pod scheduling       | `{}`                         |
| `namespace`                            | Kubernetes namespace                  | `default`                    |

**Note:** The Docker images are built with multi-architecture support (amd64 and arm64). Kubernetes will automatically select the correct architecture based on your node platform.

### Image Pull Secrets

To pull images from private container registries, you need to configure image pull secrets:

1. **Create a Docker registry secret:**

   ```bash
   kubectl create secret docker-registry regcred \
     --docker-server=<registry-url> \
     --docker-username=<username> \
     --docker-password=<password> \
     --docker-email=<email> \
     --namespace=<namespace>
   ```

   **Examples:**

   - **Docker Hub:**

     ```bash
     kubectl create secret docker-registry regcred \
       --docker-server=https://index.docker.io/v1/ \
       --docker-username=your-username \
       --docker-password=your-password \
       --docker-email=your-email@example.com
     ```

   - **GitHub Container Registry (GHCR):**

     ```bash
     kubectl create secret docker-registry ghcr-secret \
       --docker-server=ghcr.io \
       --docker-username=your-github-username \
       --docker-password=ghp_your-personal-access-token \
       --docker-email=your-email@example.com
     ```

   - **Alibaba Container Registry (ACR):**

     ```bash
     kubectl create secret docker-registry acr-secret \
       --docker-server=registry.cn-hangzhou.aliyuncs.com \
       --docker-username=your-acr-username \
       --docker-password=your-acr-password \
       --docker-email=your-email@example.com
     ```

2. **Configure in values file:**

   ```yaml
   imagePullSecrets:
     - regcred
     # Or multiple secrets:
     # - regcred
     # - ghcr-secret
   ```

3. **Or use --set during installation:**

   ```bash
   helm install cloud-cert-renewer ./helm/cloud-cert-renewer \
     --set imagePullSecrets[0]=regcred
   ```

## Secrets

### Cloud Service Credentials Secret

Create a secret with your cloud service credentials (example: Alibaba Cloud):

```bash
# Use generic naming (recommended)
kubectl create secret generic cloud-credentials \
  --from-literal=access-key-id=YOUR_ACCESS_KEY_ID \
  --from-literal=access-key-secret=YOUR_ACCESS_KEY_SECRET

# Or use old naming (backward compatible)
kubectl create secret generic alibaba-cloud-credentials \
  --from-literal=access-key-id=YOUR_ACCESS_KEY_ID \
  --from-literal=access-key-secret=YOUR_ACCESS_KEY_SECRET
```

### STS Authentication

To use STS (Security Token Service) temporary credentials:

1. Set `authMethod: sts` in your values file
2. Include `security-token` in your credentials secret:

   ```bash
   kubectl create secret generic cloud-credentials \
     --from-literal=access-key-id=YOUR_ACCESS_KEY_ID \
     --from-literal=access-key-secret=YOUR_ACCESS_KEY_SECRET \
     --from-literal=security-token=YOUR_SECURITY_TOKEN
   ```

3. Configure `secrets.cloudCredentials.securityTokenKey: "security-token"` in values

### OIDC Authentication (RRSA)

To use OIDC (OpenID Connect) authentication with RRSA (RAM Role for Service Account) in Kubernetes:

1. **Configure Service Account with RRSA annotations:**

   ```yaml
   apiVersion: v1
   kind: ServiceAccount
   metadata:
     name: cloud-cert-renewer-sa
     namespace: your-namespace
     annotations:
       pod-identity.alibabacloud.com/role-name: your-ram-role-name
   ```

2. **Set `authMethod: oidc` in your values file:**

   ```yaml
   authMethod: oidc
   ```

3. **Configure the Deployment to use the Service Account:**

   ```yaml
   serviceAccount:
     create: true
     name: cloud-cert-renewer-sa
     annotations:
       pod-identity.alibabacloud.com/role-name: your-ram-role-name
   ```

4. **OIDC parameters are automatically injected by Kubernetes:**
   - `ALIBABA_CLOUD_ROLE_ARN`: Automatically set from Service Account annotation
   - `ALIBABA_CLOUD_OIDC_PROVIDER_ARN`: Automatically set by RRSA
   - `ALIBABA_CLOUD_OIDC_TOKEN_FILE`: Automatically set by RRSA (default path)

**Note:** When using OIDC authentication, you do NOT need to create a credentials secret. The OIDC token and role information are automatically provided by the Kubernetes Service Account and RRSA.

**Reference:**

- [Alibaba Cloud RRSA Documentation](https://help.aliyun.com/zh/ack/serverless-kubernetes/user-guide/use-rrsa-to-authorize-pods-to-access-different-cloud-services)
- [Alibaba Cloud SDK Credentials Documentation](https://www.alibabacloud.com/help/en/sdk/developer-reference/v2-manage-python-access-credentials)

### Force Update

To force certificate update even if it's the same:

```yaml
forceUpdate: true
```

This sets the `FORCE_UPDATE` environment variable to `"true"`.

### Webhook Configuration

To enable webhook notifications for certificate renewal events:

#### Option 1: Configure Webhook URL in Values File

```yaml
webhook:
  enabled: true
  url: "https://hooks.slack.com/services/YOUR/SLACK/WEBHOOK"
  timeout: 30
  retryAttempts: 3
  retryDelay: 1.0
  enabledEvents: "renewal_success,renewal_failed"  # Optional: specify events
```

#### Option 2: Store Webhook URL in Secret

1. Create a secret with your webhook URL:

```bash
kubectl create secret generic webhook-secret \
  --from-literal=webhook-url=https://hooks.slack.com/services/YOUR/SLACK/WEBHOOK
```

2. Reference the secret in your values file:

```yaml
webhook:
  enabled: true
  secret:
    name: webhook-secret
    key: webhook-url
```

#### Webhook Events

The webhook system can notify on the following events:

- `renewal_started` - Certificate renewal initiated
- `renewal_success` - Certificate renewal succeeded
- `renewal_failed` - Certificate renewal failed
- `renewal_skipped` - Certificate unchanged, renewal skipped
- `batch_completed` - Batch renewal summary (for multiple resources)

If `enabledEvents` is not specified, all events will be sent.

#### Example Configurations

**Slack Integration:**

```yaml
webhook:
  enabled: true
  url: "https://hooks.slack.com/services/YOUR/SLACK/WEBHOOK"
  enabledEvents: "renewal_success,renewal_failed"
```

**Discord Integration:**

```yaml
webhook:
  enabled: true
  url: "https://discord.com/api/webhooks/YOUR/DISCORD/WEBHOOK"
  enabledEvents: "renewal_success,renewal_failed,batch_completed"
```

**Custom Webhook Server:**

```yaml
webhook:
  enabled: true
  url: "https://your-server.example.com/webhooks/cert-renewal"
  timeout: 60
  retryAttempts: 5
  retryDelay: 2.0
```

### Resources

You can configure resource requests and limits for both the init container and main container:

```yaml
initContainer:
  resources:
    requests:
      cpu: 100m
      memory: 128Mi
    limits:
      cpu: 500m
      memory: 512Mi

mainContainer:
  image: busybox:latest
  resources:
    requests:
      cpu: 10m
      memory: 32Mi
    limits:
      cpu: 100m
      memory: 128Mi
```

### Certificate Secret

The certificate secret is typically created by cert-manager. It should contain:

- `tls.crt`: The SSL certificate (PEM format)
- `tls.key`: The private key (PEM format)

## RAM Permissions (Alibaba Cloud)

When using Alibaba Cloud, you need to configure appropriate RAM (Resource Access Management) permissions for the AccessKey. The following permissions are recommended:

### Recommended Custom Policy

For CDN certificate renewal:

```json
{
  "Version": "1",
  "Statement": [
    {
      "Effect": "Allow",
      "Action": [
        "cdn:SetCdnDomainSSLCertificate",
        "cdn:DescribeDomainCertificateInfo"
      ],
      "Resource": "*"
    }
  ]
}
```

For Load Balancer (SLB) certificate renewal:

```json
{
  "Version": "1",
  "Statement": [
    {
      "Effect": "Allow",
      "Action": [
        "slb:DescribeServerCertificates",
        "slb:UploadServerCertificate",
        "slb:SetLoadBalancerHTTPSListenerAttribute",
        "slb:DescribeLoadBalancerHTTPSListenerAttribute"
      ],
      "Resource": "*"
    }
  ]
}
```

For both CDN and Load Balancer:

```json
{
  "Version": "1",
  "Statement": [
    {
      "Effect": "Allow",
      "Action": [
        "cdn:SetCdnDomainSSLCertificate",
        "cdn:DescribeDomainCertificateInfo"
      ],
      "Resource": "*"
    },
    {
      "Effect": "Allow",
      "Action": [
        "slb:DescribeServerCertificates",
        "slb:UploadServerCertificate",
        "slb:SetLoadBalancerHTTPSListenerAttribute",
        "slb:DescribeLoadBalancerHTTPSListenerAttribute"
      ],
      "Resource": "*"
    }
  ]
}
```

### Complete Policy with Resource-Specific Permissions

For a more secure configuration with resource-specific permissions and Load Balancer listener management:

```json
{
  "Version": "1",
  "Statement": [
    {
      "Effect": "Allow",
      "Action": [
        "cdn:SetCdnDomainSSLCertificate",
        "cdn:DescribeDomainCertificateInfo"
      ],
      "Resource": [
        "acs:cdn:*:*:domain/*"
      ]
    },
    {
      "Effect": "Allow",
      "Action": [
        "slb:DescribeServerCertificates",
        "slb:UploadServerCertificate",
        "slb:SetLoadBalancerHTTPSListenerAttribute",
        "slb:DescribeLoadBalancerHTTPSListenerAttribute"
      ],
      "Resource": [
        "acs:slb:*:*:certificate/*",
        "acs:slb:*:*:loadbalancer/*"
      ]
    }
  ]
}
```

**Note:** This policy includes additional permissions for Load Balancer HTTPS listener management (`slb:SetLoadBalancerHTTPSListenerAttribute` and `slb:DescribeLoadBalancerHTTPSListenerAttribute`), which may be required when updating certificates on Load Balancer listeners. The resource-specific format (`acs:cdn:*:*:domain/*` and `acs:slb:*:*:certificate/*`) provides more granular control compared to using `"Resource": "*"`.

### System Policy Alternative

Alternatively, you can use the system policy `AliyunSLBReadOnlyAccess` combined with the following custom policy:

```json
{
  "Version": "1",
  "Statement": [
    {
      "Action": [
        "slb:Describe*",
        "slb:List*",
        "slb:Get*"
      ],
      "Resource": "*",
      "Effect": "Allow"
    },
    {
      "Action": "cms:QueryMetric*",
      "Resource": "*",
      "Effect": "Allow"
    }
  ]
}
```

**Note:** The system policy `AliyunSLBReadOnlyAccess` provides read-only access. You still need to add write permissions for `slb:UploadServerCertificate` and `cdn:SetCdnDomainSSLCertificate` through a custom policy.

### Security Best Practices

- Use the principle of least privilege: only grant the minimum permissions required
- Use STS (Security Token Service) temporary credentials when possible instead of permanent AccessKeys
- Regularly rotate AccessKeys
- Use different AccessKeys for different environments (development, staging, production)

## Examples

### CDN Certificate Renewal

```yaml
serviceType: cdn
cloudProvider: alibaba
cdn:
  # Recommended: YAML list format (more readable and less error-prone)
  domainName:
    - example.com
    - cdn.example.com
  # Alternative: comma-separated string (backward compatible)
  # domainName: "example.com,cdn.example.com"
  region: cn-hangzhou
```

### Load Balancer Certificate Renewal

```yaml
serviceType: lb  # or use slb (backward compatible)
cloudProvider: alibaba
lb:
  # YAML list format (recommended):
  instanceId:
    - lb-xxxxxxxx
    - lb-yyyyyyyy
  # Or comma-separated string (backward compatible):
  # instanceId: "lb-xxxxxxxx,lb-yyyyyyyy"
  listenerPort: 443
  region: cn-hangzhou
  # Structured listeners: independent instanceId/port pairs (takes precedence when set)
  # listeners:
  #   - instanceId: lb-xxxxxxxx
  #     listenerPort: 443
  #   - instanceId: lb-yyyyyyyy
  #     listenerPort: 8443
```

### Load Balancer with CAS Certificate Path (WAF Scenario)

When using Alibaba Cloud WAF or other services that reference certificates from the Digital Certificate Management Service (CAS), set `certSource` to `cas` so the certificate is uploaded via CAS instead of the SLB self-managed certificate store:

```yaml
serviceType: lb
cloudProvider: alibaba
lb:
  instanceId:
    - lb-xxxxxxxx
  listenerPort: 443
  region: cn-hangzhou
  certSource: cas  # Upload certificate via CAS for WAF compatibility
```

## Upgrading

```bash
helm upgrade cloud-cert-renewer ./helm/cloud-cert-renewer
```

## Uninstalling

```bash
helm uninstall cloud-cert-renewer
```

## How It Works

1. **Init Container**: Runs the certificate renewal script when the pod starts or when the certificate secret changes (via Reloader)
2. **Main Container**: A placeholder container that keeps the deployment running
3. **Reloader**: Monitors the certificate secret and triggers a pod restart when it changes

## Troubleshooting

### Check Pod Status

```bash
kubectl get pods -l app.kubernetes.io/name=cloud-cert-renewer
```

### View Init Container Logs

```bash
kubectl logs <pod-name> -c cert-renewer
```

### View Main Container Logs

```bash
kubectl logs <pod-name> -c placeholder
```

## Advanced Configuration

### Custom Labels and Annotations

You can add custom labels and annotations to the Deployment and Pods:

```yaml
labels:
  environment: production
  team: platform

annotations:
  deployment.kubernetes.io/revision: "1"

podAnnotations:
  prometheus.io/scrape: "true"
  prometheus.io/port: "8080"
```

### Node Selector and Affinity

Configure pod scheduling using node selectors, tolerations, and affinity rules:

```yaml
nodeSelector:
  kubernetes.io/os: linux
  node-type: compute

tolerations:
  - key: "dedicated"
    operator: "Equal"
    value: "cert-renewer"
    effect: "NoSchedule"

affinity:
  nodeAffinity:
    requiredDuringSchedulingIgnoredDuringExecution:
      nodeSelectorTerms:
      - matchExpressions:
        - key: kubernetes.io/os
          operator: In
          values:
          - linux
```

## Multi-Cloud Support

This chart is designed to support multiple cloud providers. Currently, Alibaba Cloud is fully supported. The architecture allows for easy extension to other cloud providers (AWS, Azure, etc.) by implementing the corresponding adapters.

To use a different cloud provider, set the `cloudProvider` value accordingly (when support is added):

```yaml
cloudProvider: aws  # or azure, etc.
```

## License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.
